package filesprocessing;

/**
 * An abstract superclass for all type II exceptions.
 */
public abstract class Type1ErrorException extends Exception {}
