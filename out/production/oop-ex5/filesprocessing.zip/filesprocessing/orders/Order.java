package filesprocessing.orders;

import java.util.Comparator;
import java.io.File;

/**
 *
 */
public abstract class Order implements Comparator<File>{
}